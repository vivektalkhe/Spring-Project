package com.capgemini.psd2.account.balance.boi.foundationservice.delegate;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.balance.boi.foundationservice.transformer.AccountBalanceFoundationServiceTransformer;
import com.capgemini.psd2.aisp.domain.AccountMapping;
import com.capgemini.psd2.aisp.domain.BalancesGETResponse;
import com.capgemini.psd2.rest.client.model.RequestInfo;
import com.capgemini.psd2.rest.client.sync.impl.RestClientSyncImpl;

@Component
public class AccountBalanceFoundationServiceDelegate {
	
	@Autowired
	private RestClientSyncImpl restClient;
	
	@Autowired
	AccountBalanceFoundationServiceTransformer accountBalanceFSTransformer;
	
	@Value("${foundationService.userInReqHeader:#{X-BOI-USER}}")
	private String userInReqHeader;

	@Value("${foundationService.channelInReqHeader:#{X-BOI-CHANNEL}}")
	private String channelInReqHeader;

	@Value("${foundationService.platformInReqHeader:#{X-BOI-WORKSTATION}}")
	private String platformInReqHeader;

	@Value("${foundationService.correlationReqHeader:#{X-BOI-WORKSTATION}}")
	private String correlationReqHeader;
	
	@Value("${app.platform}")
	private String platform;

	/**
	 * Rest call to get account balance from foundation service
	 * @param reqInfo
	 * @param responseType
	 * @param headers
	 * @return
	 */
	public Accounts restTransportForSingleAccountBalance(RequestInfo reqInfo, Class <Accounts> responseType, HttpHeaders headers) {
		Accounts accounts = restClient.callForGet(reqInfo, responseType, headers);
		return accounts;
		
	}
	
	/**
	 * Method to build the Foundation Service URL
	 * @param accountNSC
	 * @param accountNumber
	 * @param baseURL
	 * @return
	 */
	public String getFoundationServiceURL(String accountNSC, String accountNumber, String baseURL){
		return baseURL + "/" + accountNSC + "/" +accountNumber;
	}
	
	/**
	 * Transform the foundation service response in CMA specs API
	 * @param account
	 * @param accountsGETResponse
	 * @param params
	 * @return
	 */
	public BalancesGETResponse transformResponseFromFDToAPI(Accounts accounts, Map<String, String> params){
		BalancesGETResponse balancesGETResponse = accountBalanceFSTransformer.transformAccountBalance(accounts, params);
		return balancesGETResponse;
	}
	
	/**
	 * Creating request headers
	 * @param requestInfo
	 * @param accountMapping
	 * @return
	 */
	public HttpHeaders createRequestHeaders(RequestInfo requestInfo, AccountMapping accountMapping) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add(userInReqHeader, accountMapping.getPsuId());
		httpHeaders.add(channelInReqHeader, accountMapping.getChannelId());
		httpHeaders.add(platformInReqHeader, platform);
		httpHeaders.add(correlationReqHeader, accountMapping.getCorrelationId());
		return httpHeaders;
	}


}
