package com.capgemini.psd2.account.balance.boi.foundationservice.transformer;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.aisp.domain.BalancesGETResponse;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseAmount;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseData;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseData.CreditDebitIndicatorEnum;
import com.capgemini.psd2.aisp.domain.BalancesGETResponseData.TypeEnum;
import com.capgemini.psd2.aisp.transformer.AcountBalanceTransformer;

@Component
public class AccountBalanceFoundationServiceTransformer implements AcountBalanceTransformer {

	@Override
	public <T> BalancesGETResponse transformAccountBalance(T inputBalanceObj, Map<String, String> params) {
		BalancesGETResponse finalGBResponseObj = new BalancesGETResponse();
		Accounts accounts = (Accounts) inputBalanceObj;
		BalancesGETResponseAmount amount = null;
		BalancesGETResponseData responseDataObj = null;
		for(Accnt accnt: accounts.getAccount()) {
			responseDataObj = new BalancesGETResponseData();
			amount = new BalancesGETResponseAmount();
			amount.setAmount(accnt.getBalance().getPostedBalance().toString());
			amount.setCurrency(accnt.getBalance().getCurrency());
			if(accnt.getBalance().getPostedBalance().compareTo(BigDecimal.ZERO)==0 || accnt.getBalance().getPostedBalance().compareTo(BigDecimal.ZERO) > 0)
				responseDataObj.setCreditDebitIndicator(CreditDebitIndicatorEnum.CREDIT);
			else
				responseDataObj.setCreditDebitIndicator(CreditDebitIndicatorEnum.DEBIT);
			responseDataObj.setAccountId(params.get("accountId"));
			//TODO:PostedBalance is not available in enum
			responseDataObj.type(TypeEnum.CLOSINGBOOKED);
			responseDataObj.setAmount(amount);
			finalGBResponseObj.getData().add(responseDataObj);
		}
		return finalGBResponseObj;
	}

	@Override
	public <T> BalancesGETResponse transfromAccountBalances(T source, Map<String, String> params) {
		// TODO Auto-generated method stub
		return null;
	}

}
