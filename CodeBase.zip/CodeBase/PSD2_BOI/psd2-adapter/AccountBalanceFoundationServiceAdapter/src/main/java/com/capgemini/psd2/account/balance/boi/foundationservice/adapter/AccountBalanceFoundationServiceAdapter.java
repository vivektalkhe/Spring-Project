package com.capgemini.psd2.account.balance.boi.foundationservice.adapter;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.balance.boi.foundationservice.delegate.AccountBalanceFoundationServiceDelegate;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.aisp.adapter.AccountBalanceAdapter;
import com.capgemini.psd2.aisp.domain.AccountMapping;
import com.capgemini.psd2.aisp.domain.BalancesGETResponse;
import com.capgemini.psd2.consent.domain.AccountDetails;
import com.capgemini.psd2.exceptions.ErrorCodeEnum;
import com.capgemini.psd2.exceptions.PSD2Exception;
import com.capgemini.psd2.rest.client.model.RequestInfo;

@Component
public class AccountBalanceFoundationServiceAdapter implements AccountBalanceAdapter {

	@Value("${foundationService.singleAccountBalanceBaseURL:#{http://10.102.19.131:8081/psd2-abt-service/services/abt/accounts}}")
	private String singleAccountBalanceBaseURL;
	
	
	@Autowired
	AccountBalanceFoundationServiceDelegate accountBalanceFoundationServiceDelegate;

	@Override
	public BalancesGETResponse retrieveAccountBalance(AccountMapping accountMapping, Map<String, String> params) {

		// Build the REST request for FD
		RequestInfo requestInfo = new RequestInfo();
		HttpHeaders httpHeaders = accountBalanceFoundationServiceDelegate.createRequestHeaders(requestInfo,	accountMapping);

		// Build the URL for FD
		AccountDetails accountDetails;
		String accountNSC;
		String accountNumber;
		if (accountMapping.getAccountDetails() != null && !accountMapping.getAccountDetails().isEmpty()) {
			accountDetails = accountMapping.getAccountDetails().get(0);
			accountNSC = accountMapping.getAccountDetails().get(0).getAccountNSC();
			accountNumber = accountMapping.getAccountDetails().get(0).getAccountNumber();
			params = new HashMap<>();
			params.put("accountId", accountDetails.getAccountId());
		} else
			throw PSD2Exception.populateBusinessException(ErrorCodeEnum.NO_ACCOUNT_DATA_FOUND);

		String finalURL = accountBalanceFoundationServiceDelegate.getFoundationServiceURL(accountNSC, accountNumber, singleAccountBalanceBaseURL);
		requestInfo.setUrl(finalURL);

		// Call the FD for Account Balance
		Accounts accounts = accountBalanceFoundationServiceDelegate.restTransportForSingleAccountBalance(requestInfo, Accounts.class, httpHeaders);
		// Transform the FD response into API response
		return accountBalanceFoundationServiceDelegate.transformResponseFromFDToAPI(accounts, params);

	}

	@Override
	public BalancesGETResponse retrieveAccountBalances(AccountMapping accountMapping, Map<String, String> params) {
		// TODO Auto-generated method stub
		return null;
	}

}
