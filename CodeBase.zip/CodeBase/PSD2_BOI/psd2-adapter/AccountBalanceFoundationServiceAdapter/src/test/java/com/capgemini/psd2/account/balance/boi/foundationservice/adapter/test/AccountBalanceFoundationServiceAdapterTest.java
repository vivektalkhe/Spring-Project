package com.capgemini.psd2.account.balance.boi.foundationservice.adapter.test;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.psd2.account.balance.boi.foundationservice.adapter.AccountBalanceFoundationServiceAdapter;
import com.capgemini.psd2.account.balance.boi.foundationservice.delegate.AccountBalanceFoundationServiceDelegate;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.balance.boi.foundationservice.domain.Balance;
import com.capgemini.psd2.aisp.domain.AccountMapping;
import com.capgemini.psd2.aisp.domain.BalancesGETResponse;
import com.capgemini.psd2.consent.domain.AccountDetails;
import com.capgemini.psd2.rest.client.sync.impl.RestClientSyncImpl;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes=AccountBalanceFoundationServiceAdapterTest.class)
public class AccountBalanceFoundationServiceAdapterTest {
	
	@InjectMocks
	private AccountBalanceFoundationServiceAdapter accountBalanceFoundationServiceAdapter;
	
	@Mock
	private RestClientSyncImpl restClient;
	
	@Mock
	AccountBalanceFoundationServiceDelegate accountBalanceFoundationServiceDelegate;
	
	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void contextLoads() {
	}
	
	@Test
	public void testAccountInformationFS() {
		Balance bal = new Balance();
		bal.setAvailableBalance(new BigDecimal(1000.00d));
		bal.setCurrency("GBP");
		bal.setPostedBalance(new BigDecimal(1000.00d));
		Accounts accounts = new Accounts();
		Accnt accnt = new Accnt();
		accnt.setBalance(bal);
		accounts.getAccount().add(accnt);	
		Mockito.when(accountBalanceFoundationServiceDelegate.getFoundationServiceURL(any(), any(), any())).thenReturn("http://10.102.19.131:8081/psd2-abt-service/services/abt/accounts/nsc1234/acct1234");
		Mockito.when(accountBalanceFoundationServiceDelegate.restTransportForSingleAccountBalance(any(), any(), any())).thenReturn(accounts);
		Mockito.when(accountBalanceFoundationServiceDelegate.transformResponseFromFDToAPI(any(), any())).thenReturn(new BalancesGETResponse());
		Mockito.when(restClient.callForGet(any(), any(), any())).thenReturn(accounts);
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc1234");
		accDet.setAccountNumber("acct1234");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCID("test");
		accountMapping.setPsuId("test");
		BalancesGETResponse res = accountBalanceFoundationServiceAdapter.retrieveAccountBalance(accountMapping, new HashMap<String,String>());
		assertNotNull(res);
	}

}
