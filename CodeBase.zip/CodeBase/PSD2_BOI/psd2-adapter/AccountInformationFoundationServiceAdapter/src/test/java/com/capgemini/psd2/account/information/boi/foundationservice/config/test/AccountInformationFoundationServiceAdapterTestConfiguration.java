package com.capgemini.psd2.account.information.boi.foundationservice.config.test;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration
@ComponentScan(basePackages={"com.capgemini.psd2"})
public class AccountInformationFoundationServiceAdapterTestConfiguration {
	
}
