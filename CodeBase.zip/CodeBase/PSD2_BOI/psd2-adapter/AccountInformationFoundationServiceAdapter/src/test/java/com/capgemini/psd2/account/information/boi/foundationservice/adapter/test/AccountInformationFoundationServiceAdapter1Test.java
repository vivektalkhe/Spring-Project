package com.capgemini.psd2.account.information.boi.foundationservice.adapter.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.psd2.account.information.boi.foundationservice.adapter.AccountInformationFoundationServiceAdapter;
import com.capgemini.psd2.account.information.boi.foundationservice.config.test.AccountInformationFoundationServiceAdapterTestConfiguration;
import com.capgemini.psd2.aisp.domain.AccountDetails;
import com.capgemini.psd2.aisp.domain.AccountMapping;
import com.capgemini.psd2.rest.client.sync.impl.RestClientSyncImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = AccountInformationFoundationServiceAdapterTestConfiguration.class)
public class AccountInformationFoundationServiceAdapter1Test {

	/*@InjectMocks
	private AccountInformationFoundationServiceAdapter accountInformationFoundationServiceAdapter;*/
	
	@Autowired
	AccountInformationFoundationServiceAdapter accountInformationFoundationServiceAdapter;
	
	/*@Mock
	private RestClientSyncImpl restClient;*/
	
	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void contextLoads() {
	}
	
	@Test
	public void testAccountInformationFS() {
		
		AccountMapping accountMapping = new AccountMapping();
		List<AccountDetails> accDetList = new ArrayList<AccountDetails>();
		AccountDetails accDet = new AccountDetails();
		accDet.setAccountId("12345");
		accDet.setAccountNSC("nsc678");
		accDet.setAccountNumber("acc678");
		accDetList.add(accDet);
		accountMapping.setAccountDetails(accDetList);
		accountMapping.setChannelId("test");
		accountMapping.setTppCId("test");
		accountMapping.setPsuId("test");
		
		accountInformationFoundationServiceAdapter.retrieveAccountInformation(accountMapping, new HashMap<String,String>());
	}

}
