package com.capgemini.psd2.account.information.boi.foundationservice.transformer;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.aisp.domain.AccountGETResponse;
import com.capgemini.psd2.aisp.domain.AccountGETResponseAccount;
import com.capgemini.psd2.aisp.domain.AccountGETResponseData;
import com.capgemini.psd2.aisp.domain.AccountGETResponseServicer;
import com.capgemini.psd2.aisp.domain.AccountGETResponseAccount.SchemeNameEnum;
import com.capgemini.psd2.aisp.transformer.AccountInformationTransformer;

@Component
public class AccountInformationFoundationServiceTransformer implements AccountInformationTransformer {

	@Override
	public <T> AccountGETResponse transformAccountInformation(T inputAccountObj, AccountGETResponse finalAIResponseObj, Map<String, String> params) {
		finalAIResponseObj = new AccountGETResponse();
		Accnt accnt = (Accnt) inputAccountObj;
		AccountGETResponseData responseObj = new AccountGETResponseData();
		responseObj.setAccountId(params.get("accountId"));
		AccountGETResponseAccount acc = new AccountGETResponseAccount();
		acc.setName(accnt.getAccountName());
		acc.setIdentification(accnt.getAccountNumber());
		//TODO to be reviewed
		if(accnt.getAccountNumber() != null && !accnt.getAccountNumber().isEmpty()) {
			acc.setSchemeName(SchemeNameEnum.BBAN);
		}else if(accnt.getIban() != null && !accnt.getIban().isEmpty()) {
			acc.setSchemeName(SchemeNameEnum.IBAN);
		}
		AccountGETResponseServicer servicer = new AccountGETResponseServicer();
		//TODO to be reviewed
		if(accnt.getAccountNsc() != null && !accnt.getAccountNsc().isEmpty()) {
			servicer.setSchemeName(com.capgemini.psd2.aisp.domain.AccountGETResponseServicer.SchemeNameEnum.UKSORTCODE);
			servicer.setIdentification(accnt.getAccountNsc());
		}else if(accnt.getIban() != null && !accnt.getIban().isEmpty()) {
			servicer.setSchemeName(com.capgemini.psd2.aisp.domain.AccountGETResponseServicer.SchemeNameEnum.BICFI);
			servicer.setIdentification(accnt.getBic());
			
		}
		responseObj.setAccount(acc);
		responseObj.setCurrency(accnt.getCurrency());
		responseObj.setNickname(accnt.getAccountName());
		responseObj.setServicer(servicer);
		
		finalAIResponseObj.getData().add(responseObj);	
		
		return finalAIResponseObj;
	}

	@Override
	public <T> AccountGETResponse transformAccountInformations(T source, AccountGETResponse destination,
			Map<String, String> params) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
