package com.capgemini.psd2.account.information.boi.foundationservice.adapter;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.information.boi.foundationservice.delegate.AccountInformationFoundationServiceDelegate;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.aisp.adapter.AccountInformationAdapter;
import com.capgemini.psd2.aisp.domain.AccountDetails;
import com.capgemini.psd2.aisp.domain.AccountGETResponse;
import com.capgemini.psd2.aisp.domain.AccountMapping;
import com.capgemini.psd2.rest.client.model.RequestInfo;

@Component
public class AccountInformationFoundationServiceAdapter implements AccountInformationAdapter{

	@Value("${foundationService.customerProfileSingleAccountBaseURL:#{http://10.102.19.131:8083/fs-accountEnquiry-service/services/AccountEnquiry/business}}")
	private String customerProfileSingleAccountBaseURL;

	@Autowired
	private AccountInformationFoundationServiceDelegate accountInformationFoundationServiceDelegate;
	
	@Override
	public AccountGETResponse retrieveAccountInformation(AccountMapping accountMapping,	Map<String, String> params) {
		
		// Build the REST request for FD
		RequestInfo requestInfo = new RequestInfo();
		HttpHeaders httpHeaders = accountInformationFoundationServiceDelegate.createRequestHeaders(requestInfo,	accountMapping);

		// Build the URL for FD
		AccountDetails accountDetails;
		String accountNSC;
		String accountNumber;
		if (accountMapping.getAccountDetails() != null && !accountMapping.getAccountDetails().isEmpty()) {

			accountDetails = accountMapping.getAccountDetails().get(0);
			accountNSC = accountMapping.getAccountDetails().get(0).accountNSC;
			accountNumber = accountMapping.getAccountDetails().get(0).accountNumber;
			params = new HashMap<>();
			params.put("accountId", accountDetails.getAccountId());
		} else
			throw new RuntimeException("Account Mapping object recieved as part of API request is INVALID!!");

		String finalURL = accountInformationFoundationServiceDelegate.getFoundationServiceURL(accountNSC, accountNumber, customerProfileSingleAccountBaseURL);
		requestInfo.setUrl(finalURL);
		
		Accounts accounts = accountInformationFoundationServiceDelegate.restTransportForSingleAccountInformation(requestInfo, Accounts.class, httpHeaders);
		Accnt accnt = accountInformationFoundationServiceDelegate.getAccountFromAccountList(accountDetails.getAccountNumber(), accounts); //There is no account id so need to identify this field
		AccountGETResponse accountGETResponse = new AccountGETResponse();
		accountGETResponse = accountInformationFoundationServiceDelegate.transformResponseFromFDToAPI(accnt, accountGETResponse, params);
		return accountGETResponse;
	}

	@Override
	public AccountGETResponse retrieveAccountInformations(AccountMapping accountMapping, Map<String, String> params) {
		// TODO Auto-generated method stub
		return null;
	}



}

