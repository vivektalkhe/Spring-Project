package com.capgemini.psd2.account.information.boi.foundationservice.delegate;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.information.boi.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.information.boi.foundationservice.transformer.AccountInformationFoundationServiceTransformer;
import com.capgemini.psd2.aisp.domain.AccountGETResponse;
import com.capgemini.psd2.aisp.domain.AccountMapping;
import com.capgemini.psd2.rest.client.model.RequestInfo;
import com.capgemini.psd2.rest.client.sync.impl.RestClientSyncImpl;

@Component
public class AccountInformationFoundationServiceDelegate {
	
	@Autowired
	private RestClientSyncImpl restClient; 
	
	@Autowired
	AccountInformationFoundationServiceTransformer accountInformationFSTransformer;
	
	@Value("${foundationService.userInReqHeader:#{X-BOI-USER}}")
	private String userInReqHeader;
	
	@Value("${foundationService.channelInReqHeader:#{X-BOI-CHANNEL}}")
	private String channelInReqHeader;
	
	@Value("${foundationService.platformInReqHeader:#{X-BOI-PLATFORM}}")
	private String platformInReqHeader;
	
	@Value("${foundationService.correlationIdInReqHeader:#{X-CORRELATION-ID}}")
	private String correlationIdInReqHeader;

	/**
	 * Rest call to get account information from foundation service
	 * @param reqInfo
	 * @param responseType
	 * @param headers
	 * @return
	 */
	public Accounts restTransportForSingleAccountInformation(RequestInfo reqInfo, Class <Accounts> responseType, HttpHeaders headers) {
		
		Accounts accounts = restClient.callForGet(reqInfo, responseType, headers);
		
		return accounts;
		
	}
	
	/**
	 * Method to build the Foundation Service URL
	 * @param accountNSC
	 * @param accountNumber
	 * @param baseURL
	 * @return
	 */
	public String getFoundationServiceURL(String accountNSC, String accountNumber, String baseURL){
		return baseURL + "/" + accountNSC + "/" +accountNumber + "/" + "account";
	}
	
	/**
	 * Transform the foundation service response in CMA specs API
	 * @param account
	 * @param accountsGETResponse
	 * @param params
	 * @return
	 */
	public AccountGETResponse transformResponseFromFDToAPI(Accnt accnt, AccountGETResponse accountGETResponse, Map<String, String> params){
		
		accountGETResponse = accountInformationFSTransformer.transformAccountInformation(accnt, accountGETResponse, params);
	
		return accountGETResponse;
	}
	
	/**
	 * To get the required account from account list returned as per user profile.
	 * @param accoutnId
	 * @param accounts
	 * @return
	 */
	public Accnt getAccountFromAccountList(String accountNumber, Accounts accounts){
		
		for(Accnt account: accounts.getAccount()) {
			if(account.getAccountNumber().equalsIgnoreCase(accountNumber)) {
				return account;
			}
		}
		
		return null;
		
	}
	
	/**
	 * Creating request headers
	 * @param requestInfo
	 * @param accountMapping
	 * @return
	 */
	public HttpHeaders createRequestHeaders(RequestInfo requestInfo, AccountMapping accountMapping) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add(userInReqHeader, accountMapping.getPsuId());
		httpHeaders.add(channelInReqHeader, accountMapping.getChannelId());
		httpHeaders.add(platformInReqHeader, accountMapping.getChannelId());
		httpHeaders.add(correlationIdInReqHeader, accountMapping.getChannelId());
		return httpHeaders;
	}
}
