package com.capgemini.psd2.account.information.mock.foundationservice.test;

import org.junit.Test;


public class AccountInformationApplicationTest {

	@Test
	public void contextLoads() {
	}
	
}
