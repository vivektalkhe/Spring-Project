package com.capgemini.psd2.account.information.mock.foundationservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.capgemini.psd2.account.information.mock.foundationservice.domain.Accnt;

public interface AccountInformationRepository extends MongoRepository<Accnt, String> {

	public Accnt findByAccountNscAndAccountNumber(String accountNsc, String accountNumber);

}
