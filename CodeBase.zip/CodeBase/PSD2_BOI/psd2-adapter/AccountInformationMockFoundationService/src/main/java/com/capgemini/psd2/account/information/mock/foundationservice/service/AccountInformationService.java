package com.capgemini.psd2.account.information.mock.foundationservice.service;

import com.capgemini.psd2.account.information.mock.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.information.mock.foundationservice.exception.handler.RecordNotFoundException;

public interface AccountInformationService {

	public Accounts  retrieveAccountInformation(String nsc, String accountNumber) throws RecordNotFoundException;

	
}
