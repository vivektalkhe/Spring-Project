package com.capgemini.psd2.account.information.mock.foundationservice.exception.handler;

public class RecordNotFoundException extends Exception {

	public RecordNotFoundException(String s){
		super(s);
		
	}
	
}
