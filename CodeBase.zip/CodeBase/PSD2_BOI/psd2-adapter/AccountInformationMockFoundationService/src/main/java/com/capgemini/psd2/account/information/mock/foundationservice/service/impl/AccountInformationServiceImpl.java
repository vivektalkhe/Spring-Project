package com.capgemini.psd2.account.information.mock.foundationservice.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.psd2.account.information.mock.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.information.mock.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.information.mock.foundationservice.exception.handler.RecordNotFoundException;
import com.capgemini.psd2.account.information.mock.foundationservice.repository.AccountInformationRepository;
import com.capgemini.psd2.account.information.mock.foundationservice.service.AccountInformationService;

@Service
public class AccountInformationServiceImpl implements AccountInformationService {

	@Autowired
	private AccountInformationRepository repository;

	@Override
	public Accounts retrieveAccountInformation(String accountNsc, String accountNumber) throws RecordNotFoundException {

		Accnt accnt = repository.findByAccountNscAndAccountNumber(accountNsc, accountNumber);
		
		if (accnt == null) {
			throw new RecordNotFoundException("Not Found");
		}
		
		Accounts account = new Accounts();
		account.getAccount().add(accnt);

		return account;

	}

}
