package com.capgemini.psd2.account.information.mock.foundationservice.exception.handler;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.capgemini.psd2.account.information.mock.foundationservice.domain.ValidationViolation;

@ControllerAdvice
public class MockExceptionHandler extends ResponseEntityExceptionHandler {

	
	
	@ExceptionHandler(RecordNotFoundException.class)
	public final ResponseEntity<ValidationViolation> recordNotFound(Exception ex) {

		ValidationViolation exceptionResponce = new ValidationViolation();

		exceptionResponce.setErrorCode("404");
		exceptionResponce.setErrorText("FS_AE_002: This request cannot be processed. Account not found");
		return new ResponseEntity<ValidationViolation>(exceptionResponce, new HttpHeaders(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MissingAuthenticationHeaderException.class)
	public final ResponseEntity<ValidationViolation> missingAuthenticationHeaderException(Exception ex) {

		ValidationViolation exceptionResponce = new ValidationViolation();

		exceptionResponce.setErrorCode("401");
		exceptionResponce.setErrorText("FS_AE_001: You are not authorised to use this service");
		return new ResponseEntity<ValidationViolation>(exceptionResponce, new HttpHeaders(), HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ValidationViolation> internalServerError(Exception ex) {

		ValidationViolation exceptionResponce = new ValidationViolation();

		exceptionResponce.setErrorCode("500");
		exceptionResponce.setErrorText("PSD2_FS_ABTB_EM_004: Technical Error. Please try again later");
		return new ResponseEntity<ValidationViolation>(exceptionResponce, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

}