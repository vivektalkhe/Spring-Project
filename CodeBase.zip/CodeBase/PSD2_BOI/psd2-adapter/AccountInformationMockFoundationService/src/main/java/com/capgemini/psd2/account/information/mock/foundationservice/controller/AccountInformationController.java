package com.capgemini.psd2.account.information.mock.foundationservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.psd2.account.information.mock.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.information.mock.foundationservice.exception.handler.MissingAuthenticationHeaderException;
import com.capgemini.psd2.account.information.mock.foundationservice.exception.handler.RecordNotFoundException;
import com.capgemini.psd2.account.information.mock.foundationservice.service.AccountInformationService;

@RestController
@RequestMapping("/fs-accountEnquiry-service/services/AccountEnquiry")
public class AccountInformationController {

	@Autowired
	private AccountInformationService accountInformationService;

	@RequestMapping(value = "/business/{nsc}/{accountNumber}/account", method = RequestMethod.GET, produces = "application/xml")
	@ResponseBody
	public Accounts channelAReteriveAccountInformation(@PathVariable("nsc") String accountNsc,
			@PathVariable("accountNumber") String accountNumber,
			@RequestHeader(required = false,value="X-BOI-USER") String boiUser,
			@RequestHeader(required = false,value="X-BOI-CHANNEL") String boiChannel,
			@RequestHeader(required = false,value="X-BOI-PLATFORM") String boiPlatform,
			@RequestHeader(required = false,value="X-CORRELATION-ID") String correlationID) throws MissingAuthenticationHeaderException, RecordNotFoundException, Exception{
		
		if(boiUser==null || boiChannel==null || boiPlatform==null || correlationID==null ){
			throw new MissingAuthenticationHeaderException("Header Missing");
		}

		return accountInformationService.retrieveAccountInformation(accountNsc, accountNumber);
		
	}
	
	@RequestMapping(value = "/personal/{nsc}/{accountNumber}/account", method = RequestMethod.GET, produces = "application/xml")
	@ResponseBody
	public Accounts channelBReteriveAccountInformation(@PathVariable("nsc") String accountNsc,
			@PathVariable("accountNumber") String accountNumber,
			@RequestHeader(required = false,value="X-BOI-USER") String boiUser,
			@RequestHeader(required = false,value="X-BOI-CHANNEL") String boiChannel,
			@RequestHeader(required = false,value="X-BOI-PLATFORM") String boiPlatform,
			@RequestHeader(required = false,value="X-CORRELATION-ID") String correlationID) throws MissingAuthenticationHeaderException, RecordNotFoundException, Exception {
		
		if(boiUser==null || boiChannel==null || boiPlatform==null || correlationID==null ){
			throw new MissingAuthenticationHeaderException("Header Missing");
		}

		return accountInformationService.retrieveAccountInformation(accountNsc, accountNumber);
		

	}

}
