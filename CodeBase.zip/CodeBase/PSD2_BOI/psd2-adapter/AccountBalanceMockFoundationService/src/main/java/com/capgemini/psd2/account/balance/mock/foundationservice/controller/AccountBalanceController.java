package com.capgemini.psd2.account.balance.mock.foundationservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.psd2.account.balance.mock.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.balance.mock.foundationservice.exception.handler.MissingAuthenticationHeaderException;
import com.capgemini.psd2.account.balance.mock.foundationservice.exception.handler.RecordNotFoundException;
import com.capgemini.psd2.account.balance.mock.foundationservice.service.AccountBalanceService;


@RestController
@RequestMapping("/fs-abt-service/services/abt")
public class AccountBalanceController {

	@Autowired
	private AccountBalanceService accountBalanceService;

	@RequestMapping(value = "/accounts/{nsc}/{accountNumber}", method=RequestMethod.GET, produces = "application/xml")
	public Accounts reteriveAccountInformation(
			@PathVariable("nsc") String nsc,
			@PathVariable("accountNumber") String accountNumber,
			@RequestHeader(required = false,value="X-BOI-USER") String boiUser,
			@RequestHeader(required = false,value="X-BOI-CHANNEL") String boiChannel,
			@RequestHeader(required = false,value="X-BOI-PLATFORM") String boiPlatform,
			@RequestHeader(required = false,value="X-CORRELATION-ID") String correlationID) throws RecordNotFoundException, MissingAuthenticationHeaderException, Exception {
		
		if(boiUser==null || boiChannel==null || boiPlatform==null || correlationID==null ){
			throw new MissingAuthenticationHeaderException("Header Missing");
		}
		
		return accountBalanceService.retrieveAccountBalance(nsc, accountNumber);
		
		
		
		
	}

}
