package com.capgemini.psd2.account.balance.mock.foundationservice.exception.handler;

public class RecordNotFoundException extends Exception {

	public RecordNotFoundException(String r){
		super(r);
		
	}
	
}
