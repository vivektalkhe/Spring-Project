package com.capgemini.psd2.account.balance.mock.foundationservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.capgemini.psd2.account.balance.mock.foundationservice.domain.Accnt;

public interface AccountBalanceRepository extends MongoRepository<Accnt , String> {

	public Accnt findByNscAndAccountNumber(String nsc, String accountNumber);
	

}

