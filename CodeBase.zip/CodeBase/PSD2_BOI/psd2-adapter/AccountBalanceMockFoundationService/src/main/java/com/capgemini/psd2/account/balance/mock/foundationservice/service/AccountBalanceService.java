package com.capgemini.psd2.account.balance.mock.foundationservice.service;

import com.capgemini.psd2.account.balance.mock.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.balance.mock.foundationservice.exception.handler.RecordNotFoundException;

public interface AccountBalanceService {

	public Accounts  retrieveAccountBalance(String nsc, String accountNumber) throws RecordNotFoundException;
	
}

