package com.capgemini.psd2.account.balance.mock.foundationservice.exception.handler;

public class MissingAuthenticationHeaderException extends Exception{

	public MissingAuthenticationHeaderException(String m){
		super(m);
	}
	
}
