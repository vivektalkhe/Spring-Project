package com.capgemini.psd2.account.balance.mock.foundationservice.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.psd2.account.balance.mock.foundationservice.domain.Accnt;
import com.capgemini.psd2.account.balance.mock.foundationservice.domain.Accounts;
import com.capgemini.psd2.account.balance.mock.foundationservice.exception.handler.RecordNotFoundException;
import com.capgemini.psd2.account.balance.mock.foundationservice.repository.AccountBalanceRepository;
import com.capgemini.psd2.account.balance.mock.foundationservice.service.AccountBalanceService;

@Service
public class AccountBalanceServiceImpl implements AccountBalanceService {

	@Autowired
	private AccountBalanceRepository repository;

	@Override
	public Accounts retrieveAccountBalance(String nsc, String accountNumber) throws RecordNotFoundException {

		Accnt accnt = repository.findByNscAndAccountNumber(nsc, accountNumber);

		if (accnt == null) {
			throw new RecordNotFoundException("Not Found");
		}
		Accounts account = new Accounts();
		account.getAccount().add(accnt);

		return account;

	}

}
