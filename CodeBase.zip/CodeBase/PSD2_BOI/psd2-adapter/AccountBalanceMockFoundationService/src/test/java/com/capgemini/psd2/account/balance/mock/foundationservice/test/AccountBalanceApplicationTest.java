package com.capgemini.psd2.account.balance.mock.foundationservice.test;

import org.junit.Test;


public class AccountBalanceApplicationTest {

	@Test
	public void contextLoads() {
	}
	
}
